package com.example.LabApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(LabApiApplication.class, args);
	}

}
